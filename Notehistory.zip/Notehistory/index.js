var button=document.querySelector('#notHistory');
button.addEventListener("click",function note(){


  $.ajax({
  method: "GET",
  url: "https://jsonplaceholder.typicode.com/posts"

})
.done(function( msg ) {

      for(let s of msg ){

          if(s.userId==1){
          console.log(s.id);
          console.log(s.title);
          console.log(s.body);

          // for(let s of msg){
          //     if(s.astate==true){
          //     console.log(s.id);
          //     console.log(s.title);
          //     console.log(s.content);
          //       //console.log(s.atimestamp);     our time stamp..if the below log doesnot work please remoeve //
          //     console.log(timeConverter(s.atimestamp));




          }
      }
  })
});

/*
function timeConverter(UNIX_timestamp){
  var a = new Date(UNIX_timestamp * 1000);
  var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  var year = a.getFullYear();
  var month = months[a.getMonth()];
  var date = a.getDate();
  var hour = a.getHours();
  var min = a.getMinutes();
  var sec = a.getSeconds();
  var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec ;
  return time;
}*/
